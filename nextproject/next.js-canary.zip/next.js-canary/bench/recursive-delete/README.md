# Recursive Delete Benchmark

```bash
pnpm bench
```

Run `pnpm bench --help` for options.
