'use client'
import * as Mermaid from 'mermaid'

console.log(Mermaid)
// console.log(Mantine.Button.Group.classes);

export function MermaidComponent() {
  return (
    <>
      <h1>Client Component</h1>
    </>
  )
}
