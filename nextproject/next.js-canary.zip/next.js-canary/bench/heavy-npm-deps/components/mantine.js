'use client'
import * as Mantine from '@mantine/core'

console.log(Mantine.Button.Group.classes)

export function MantineComponent() {
  return (
    <>
      <h1>Client Component</h1>
    </>
  )
}
