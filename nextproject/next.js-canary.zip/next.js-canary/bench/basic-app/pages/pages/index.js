export default () => 'Hello World'

export function getServerSideProps() {
  return {
    props: {},
  }
}
