module.exports = {
  experimental: {
    serverMinification: true,
  },
}
