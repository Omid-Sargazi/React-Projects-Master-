'use client'
import React from 'react'

import Comp from '../../components/index.jsx'

export default function Home() {
  return (
    <>
      <h1>Hello!</h1>
      <Comp />
    </>
  )
}
