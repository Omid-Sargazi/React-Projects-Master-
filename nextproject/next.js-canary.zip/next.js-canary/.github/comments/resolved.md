This issue has been resolved on a newer version of the package. Please update to `next@latest` or `next@canary` to test it out!

If you think this issue was closed by mistake, or the issue still persists on the newest version, please open a new issue with the latest version of the package.

Thank you!
