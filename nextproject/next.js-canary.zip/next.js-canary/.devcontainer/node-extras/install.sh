#!/bin/bash
set -euxo pipefail

corepack enable pnpm
