import { Inter } from '@next/font/google'

const { a } = Inter({
  variant: '400',
})

const [b] = Inter({
  variant: '400',
})

const { e } = {}
