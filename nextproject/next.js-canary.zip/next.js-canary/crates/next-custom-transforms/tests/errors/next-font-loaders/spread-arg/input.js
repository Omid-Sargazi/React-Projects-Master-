import { Inter } from '@next/font/google'

const a = fn(...{}, ...[])
const inter = Inter(...{}, ...[])
