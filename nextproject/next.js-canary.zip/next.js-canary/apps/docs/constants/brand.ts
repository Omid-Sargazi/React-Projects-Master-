export const NEXTJS = 'Next.js'
